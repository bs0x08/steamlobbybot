# pavetr
# =============================
# SteamLobbyBot (SLB)
# =============================
# install:
#   pip install -U discord.py aiosqlite aiohttp python-dotenv
#
# .env:
#   DISCORD_TOKEN=...         # discord key
#   STEAM_API_KEY=...         # steam api key
# run:
#   python bot.py
#
# commands:
#   /registerid steamid   : link your SteamID64 (17 digits)
#   /unregisterid         : remove your linked SteamID
#   /whoisplaying game    : show registered users currently playing a game
#
# note:
#   - Game search works with short names (cs2, tf2, dota2, pubg, gta5, etc.) and FULL names from Steam AppList
#   - All Steam games list is taken from https://api.steampowered.com/ISteamApps/GetAppList/v2/ and cached locally
#   - developer: bs0x08
#   - web: bs0x08.github.io

import os
import re
import json
import asyncio
import aiohttp
import aiosqlite
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

# =============================
# cfg and globals
# =============================
load_dotenv()
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "")
STEAM_API_KEY = os.getenv("STEAM_API_KEY", "")

if not DISCORD_TOKEN:
    raise RuntimeError("DISCORD_TOKEN not set (create .env)")
if not STEAM_API_KEY:
    raise RuntimeError("STEAM_API_KEY not set (create .env)")

DB_PATH = "steamlobby.sqlite3"
GAMES_CACHE_JSON = "steam_applist_cache.json"
GAMES_CACHE_TTL_HOURS = 24  # refresh game list (new games (?))

intents = discord.Intents.default()
intents.guilds = True
intents.members = True  # needed for mentions and member checks

bot = commands.Bot(command_prefix="/", intents=intents)

# pgsn (popular game shor names)
GAME_ALIASES: Dict[str, str] = {
    "cs2": "Counter-Strike 2",
    "csgo": "Counter-Strike: Global Offensive",
    "tf2": "Team Fortress 2",
    "dota2": "Dota 2",
    "pubg": "PUBG: BATTLEGROUNDS",
    "gta5": "Grand Theft Auto V",
    "apex": "Apex Legends",
    "rust": "Rust",
    "valheim": "Valheim",
    "r6": "Tom Clancy's Rainbow Six Siege",
    "r6s": "Tom Clancy's Rainbow Six Siege",
    "warzone": "Call of Duty®",
    "gmod": "Garry's Mod",
}

# =============================
# db util
# =============================
CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS registrations (
    guild_id   INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    steam_id   TEXT    NOT NULL,
    PRIMARY KEY (guild_id, user_id)
);
"""

async def init_db() -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(CREATE_TABLE_SQL)
        await db.commit()

async def register_user(guild_id: int, user_id: int, steam_id: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "REPLACE INTO registrations (guild_id, user_id, steam_id) VALUES (?, ?, ?)",
            (guild_id, user_id, steam_id),
        )
        await db.commit()

async def unregister_user(guild_id: int, user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "DELETE FROM registrations WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id),
        )
        await db.commit()
        return cur.rowcount

async def get_registered_users(guild_id: int) -> List[Tuple[int, str]]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT user_id, steam_id FROM registrations WHERE guild_id = ?",
            (guild_id,),
        )
        rows = await cur.fetchall()
        return [(int(user_id), steam_id) for (user_id, steam_id) in rows]

# =============================
# sapi util
# =============================
async def fetch_json(session: aiohttp.ClientSession, url: str) -> dict:
    async with session.get(url, timeout=aiohttp.ClientTimeout(total=20)) as resp:
        resp.raise_for_status()
        return await resp.json(content_type=None)

async def load_applist() -> Dict[str, int]:
    """Load and/or refresh the full Steam game list. Cache locally for 24h."""
    # try reading cache
    try:
        if os.path.exists(GAMES_CACHE_JSON):
            with open(GAMES_CACHE_JSON, "r", encoding="utf-8") as f:
                cached = json.load(f)
            ts = datetime.fromisoformat(cached.get("timestamp"))
            if datetime.utcnow() - ts < timedelta(hours=GAMES_CACHE_TTL_HOURS):
                return {k: int(v) for k, v in cached["games"].items()}
    except Exception:
        pass

    # otherwise download
    url = "https://api.steampowered.com/ISteamApps/GetAppList/v2/"
    async with aiohttp.ClientSession() as session:
        data = await fetch_json(session, url)
        apps = data.get("applist", {}).get("apps", [])
        mapping = {app.get("name", "").lower(): int(app.get("appid")) for app in apps if app.get("name")}

    # save cache
    try:
        with open(GAMES_CACHE_JSON, "w", encoding="utf-8") as f:
            json.dump({"timestamp": datetime.utcnow().isoformat(), "games": mapping}, f, ensure_ascii=False)
    except Exception:
        pass

    return mapping

async def resolve_game(game_query: str, applist: Dict[str, int]) -> Tuple[Optional[str], Optional[int]]:
    """Return (full_name, appid) by alias or exact name. Requires strict match."""
    q = game_query.strip().lower()
    # check aliases
    if q in GAME_ALIASES:
        full_name = GAME_ALIASES[q]
        return full_name, applist.get(full_name.lower())
    # exact name
    if q in applist:
        return game_query.strip(), applist[q]
    return None, None

async def steam_get_player_summaries(steam_ids: List[str]) -> List[dict]:
    """ISteamUser/GetPlayerSummaries — up to 100 SteamIDs per request."""
    result: List[dict] = []
    async with aiohttp.ClientSession() as session:
        for i in range(0, len(steam_ids), 100):
            chunk = steam_ids[i:i+100]
            ids_str = ",".join(chunk)
            url = (
                "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/"
                f"?key={STEAM_API_KEY}&steamids={ids_str}"
            )
            data = await fetch_json(session, url)
            players = data.get("response", {}).get("players", [])
            result.extend(players)
            await asyncio.sleep(0.2)  # soft rate-limit
    return result

# =============================
# validators
# =============================
STEAMID64_RE = re.compile(r"^\d{17}$")

def is_valid_steamid64(s: str) -> bool:
    return bool(STEAMID64_RE.match(s))

# =============================
# app_commands
# =============================
class SteamLobby(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.applist: Dict[str, int] = {}

    async def cog_load(self) -> None:
        # init db
        await init_db()
        self.applist = await load_applist()

    # ---------- /registerid ----------
    @app_commands.command(name="registerid", description="Link your SteamID64 to the bot")
    @app_commands.describe(steamid="Your SteamID64 (17 digits)")
    async def registerid(self, interaction: discord.Interaction, steamid: str):
        if interaction.guild is None:
            return await interaction.response.send_message("This command is only available in a server.", ephemeral=True)
        if not is_valid_steamid64(steamid):
            return await interaction.response.send_message(
                "Invalid SteamID64. It must be a 17-digit number (e.g., 7656119XXXXXXXXXX).",
                ephemeral=True,
            )
        await register_user(interaction.guild.id, interaction.user.id, steamid)
        await interaction.response.send_message(
            f"✅ Linked successfully. {interaction.user.mention} → SteamID64 `{steamid}`",
            allowed_mentions=discord.AllowedMentions(users=True),
        )

    # ---------- /unregisterid ----------
    @app_commands.command(name="unregisterid", description="Remove your linked SteamID from the bot")
    async def unregisterid(self, interaction: discord.Interaction):
        if interaction.guild is None:
            return await interaction.response.send_message("This command is only available in a server.", ephemeral=True)
        deleted = await unregister_user(interaction.guild.id, interaction.user.id)
        if deleted:
            await interaction.response.send_message(f"🗑️ Link removed, {interaction.user.mention}.")
        else:
            await interaction.response.send_message("You don't have a linked SteamID.", ephemeral=True)


# ---------- /whoisplaying ----------
    @app_commands.command(name="whoisplaying", description="Show which registered users are currently playing a game")
    @app_commands.describe(game="Short name (cs2, tf2, dota2, ...) or FULL game name from Steam")
    async def whoisplaying(self, interaction: discord.Interaction, game: str):
        import traceback
        try:
            if interaction.guild is None:
                return await interaction.response.send_message(
                    "This command is only available in a server.", ephemeral=True
                )

            self.applist = await load_applist()

            full_name, appid = await resolve_game(game, self.applist)
            if not appid:
                return await interaction.response.send_message(
                    "❌ Game not found. Use a short name (e.g., `cs2`) or FULL name from Steam AppList.",
                    ephemeral=True,
                )

            regs = await get_registered_users(interaction.guild.id)
            if not regs:
                return await interaction.response.send_message(
                    "No registered users on this server. Players must use `/registerid` first.",
                    ephemeral=True,
                )

            await interaction.response.defer(thinking=True)

            steam_ids = [steam_id for (_uid, steam_id) in regs]
            summaries = await steam_get_player_summaries(steam_ids)
            print("DEBUG summaries:", json.dumps(summaries, indent=2, ensure_ascii=False))

            playing_map: Dict[str, Tuple[Optional[str], Optional[int]]] = {}
            for p in summaries:
                sid = p.get("steamid")
                gameid = p.get("gameid")
                gameextrainfo = p.get("gameextrainfo")
                if sid:
                    if gameid:
                        try:
                            playing_map[sid] = (gameextrainfo, int(gameid))
                        except ValueError:
                            playing_map[sid] = (gameextrainfo, None)
                    else:
                        playing_map[sid] = (None, None)

            matched_users: List[Tuple[str, str]] = []
            for discord_user_id, steam_id in regs:
                info = playing_map.get(steam_id)
                if not info:
                    continue
                now_playing_name, current_appid = info
                if current_appid == appid or (now_playing_name and now_playing_name.lower() == full_name.lower()):
                    member = interaction.guild.get_member(discord_user_id)
                    if member:
                        matched_users.append((member.display_name, steam_id))

            if matched_users:
                names_lines = [
                    f"**[{name}](https://steamcommunity.com/profiles/{steam_id}/)**"
                    for name, steam_id in matched_users
                ]
                names_text = "\n".join(names_lines)

                embed = discord.Embed(
                    title=f"🎮 Currently playing {full_name}",
                    description=names_text,
                    color=0x1c73ff
                )
                embed.set_footer(text=f"AppID: {appid} | Players: {len(matched_users)}")
                await interaction.followup.send(embed=embed)
            else:
                await interaction.followup.send(
                    f"😴 No registered users are currently playing **{full_name}** (`appid {appid}`)."
                )
        except Exception as e:
            traceback.print_exc()
            if not interaction.response.is_done():
                await interaction.response.send_message("⚠️ Internal error. See logs.", ephemeral=True)




# =============================
# sync
# =============================
@bot.event
async def on_ready():
    try:
        await bot.add_cog(SteamLobby(bot))
    except Exception as e:
        print("Error loading COG:", e)
    # global slash command sync
    try:
        synced = await bot.tree.sync()
        print(f"Synced slash commands: {len(synced)}")
    except Exception as e:
        print("Error during sync():", e)
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")

if __name__ == "__main__":
    bot.run(DISCORD_TOKEN)


