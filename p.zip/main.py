# pavetr
# =============================
# SteamLobbyBot (SLB)
# =============================
# install:
#   pip install -U discord.py aiosqlite aiohttp python-dotenv
#
# .env:
#   DISCORD_TOKEN=...         # discord key
#   STEAM_API_KEY=...         # steam api key
# run:
#   python bot.py
#
# commands:
#   /registerid steamid   : link your SteamID64 (17 digits)
#   /unregisterid         : remove your linked SteamID
#   /whoisplaying game    : show registered users currently playing a game
#
# note:
#   - Game search works with short names (cs2, tf2, dota2, pubg, gta5, etc.) and FULL names from Steam AppList
#   - All Steam games list is taken from https://api.steampowered.com/ISteamApps/GetAppList/v2/ and cached locally
#   - developer: bs0x08
#   - web: bs0x08.github.io

import os
import re
import json
import asyncio
import aiohttp
import aiosqlite
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

# =============================
# cfg and globals
# =============================
load_dotenv()
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "")
STEAM_API_KEY = os.getenv("STEAM_API_KEY", "")

if not DISCORD_TOKEN:
    raise RuntimeError("DISCORD_TOKEN not set (create .env)")
if not STEAM_API_KEY:
    raise RuntimeError("STEAM_API_KEY not set (create .env)")

DB_PATH = "steamlobby.sqlite3"
GAMES_CACHE_JSON = "steam_applist_cache.json"
GAMES_CACHE_TTL_HOURS = 24

intents = discord.Intents.default()
intents.guilds = True
intents.members = True

bot = commands.Bot(command_prefix="/", intents=intents)

GAME_ALIASES: Dict[str, str] = {
    "cs2": "Counter-Strike 2",
    "csgo": "Counter-Strike: Global Offensive",
    "tf2": "Team Fortress 2",
    "dota2": "Dota 2",
    "pubg": "PUBG: BATTLEGROUNDS",
    "gta5": "Grand Theft Auto V",
    "apex": "Apex Legends",
    "rust": "Rust",
    "valheim": "Valheim",
    "r6": "Tom Clancy's Rainbow Six Siege",
    "r6s": "Tom Clancy's Rainbow Six Siege",
    "warzone": "Call of Duty®",
    "gmod": "Garry's Mod",
}

# =============================
# db util
# =============================
CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS registrations (
    guild_id   INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    steam_id   TEXT    NOT NULL,
    PRIMARY KEY (guild_id, user_id)
);
"""

async def init_db() -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(CREATE_TABLE_SQL)
        await db.commit()

async def register_user(guild_id: int, user_id: int, steam_id: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "REPLACE INTO registrations (guild_id, user_id, steam_id) VALUES (?, ?, ?)",
            (guild_id, user_id, steam_id),
        )
        await db.commit()

async def unregister_user(guild_id: int, user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "DELETE FROM registrations WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id),
        )
        await db.commit()
        return cur.rowcount

async def get_registered_users(guild_id: int) -> List[Tuple[int, str]]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT user_id, steam_id FROM registrations WHERE guild_id = ?",
            (guild_id,),
        )
        rows = await cur.fetchall()
        return [(int(user_id), steam_id) for (user_id, steam_id) in rows]

# =============================
# sapi util
# =============================
async def fetch_json(session: aiohttp.ClientSession, url: str) -> dict:
    async with session.get(url, timeout=aiohttp.ClientTimeout(total=20)) as resp:
        resp.raise_for_status()
        return await resp.json(content_type=None)

async def load_applist() -> Dict[str, int]:
    try:
        if os.path.exists(GAMES_CACHE_JSON):
            with open(GAMES_CACHE_JSON, "r", encoding="utf-8") as f:
                cached = json.load(f)
            ts = datetime.fromisoformat(cached.get("timestamp"))
            if datetime.utcnow() - ts < timedelta(hours=GAMES_CACHE_TTL_HOURS):
                return {k: int(v) for k, v in cached["games"].items()}
    except Exception:
        pass

    url = "https://api.steampowered.com/ISteamApps/GetAppList/v2/"
    async with aiohttp.ClientSession() as session:
        data = await fetch_json(session, url)
        apps = data.get("applist", {}).get("apps", [])
        mapping = {app.get("name", "").lower(): int(app.get("appid")) for app in apps if app.get("name")}

    try:
        with open(GAMES_CACHE_JSON, "w", encoding="utf-8") as f:
            json.dump({"timestamp": datetime.utcnow().isoformat(), "games": mapping}, f, ensure_ascii=False)
    except Exception:
        pass

    return mapping

async def resolve_game(game_query: str, applist: Dict[str, int]) -> Tuple[Optional[str], Optional[int]]:
    q = game_query.strip().lower()
    if q in GAME_ALIASES:
        full_name = GAME_ALIASES[q]
        return full_name, applist.get(full_name.lower())
    if q in applist:
        return game_query.strip(), applist[q]
    return None, None

async def steam_get_player_summaries(steam_ids: List[str]) -> List[dict]:
    result: List[dict] = []
    async with aiohttp.ClientSession() as session:
        for i in range(0, len(steam_ids), 100):
            chunk = steam_ids[i:i+100]
            ids_str = ",".join(chunk)
            url = (
                "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/"
                f"?key={STEAM_API_KEY}&steamids={ids_str}"
            )
            data = await fetch_json(session, url)
            players = data.get("response", {}).get("players", [])
            result.extend(players)
            await asyncio.sleep(0.2)
    return result

async def steam_get_owned_games(steamid: str) -> List[dict]:
    url = (
        "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/"
        f"?key={STEAM_API_KEY}&steamid={steamid}&include_appinfo=1"
    )
    async with aiohttp.ClientSession() as session:
        data = await fetch_json(session, url)
        return data.get("response", {}).get("games", [])

# =============================
# validators
# =============================
STEAMID64_RE = re.compile(r"^\d{17}$")

def is_valid_steamid64(s: str) -> bool:
    return bool(STEAMID64_RE.match(s))

# =============================
# app_commands
# =============================
class SteamLobby(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.applist: Dict[str, int] = {}

    async def cog_load(self) -> None:
        await init_db()
        self.applist = await load_applist()

    # /registerid
    @app_commands.command(name="registerid", description="Link your SteamID64 to the bot")
    async def registerid(self, interaction: discord.Interaction, steamid: str):
        if interaction.guild is None:
            return await interaction.response.send_message("This command is only available in a server.", ephemeral=True)
        if not is_valid_steamid64(steamid):
            return await interaction.response.send_message("Invalid SteamID64.", ephemeral=True)
        await register_user(interaction.guild.id, interaction.user.id, steamid)
        await interaction.response.send_message(f"✅ Linked {interaction.user.mention} → `{steamid}`")

    # /unregisterid
    @app_commands.command(name="unregisterid", description="Remove your linked SteamID")
    async def unregisterid(self, interaction: discord.Interaction):
        if interaction.guild is None:
            return await interaction.response.send_message("This command is only available in a server.", ephemeral=True)
        deleted = await unregister_user(interaction.guild.id, interaction.user.id)
        if deleted:
            await interaction.response.send_message(f"🗑️ Link removed, {interaction.user.mention}.")
        else:
            await interaction.response.send_message("You don't have a linked SteamID.", ephemeral=True)

    # /whoisplaying
    @app_commands.command(name="whoisplaying", description="Show who is playing a game")
    async def whoisplaying(self, interaction: discord.Interaction, game: str):
        if interaction.guild is None:
            return await interaction.response.send_message("Only in server.", ephemeral=True)

        self.applist = await load_applist()
        full_name, appid = await resolve_game(game, self.applist)
        if not appid:
            return await interaction.response.send_message("❌ Game not found.", ephemeral=True)

        regs = await get_registered_users(interaction.guild.id)
        if not regs:
            return await interaction.response.send_message("No registered users.", ephemeral=True)

        await interaction.response.defer(thinking=True)
        steam_ids = [s for (_u, s) in regs]
        summaries = await steam_get_player_summaries(steam_ids)

        playing = []
        for p in summaries:
            if str(p.get("gameid")) == str(appid):
                member = interaction.guild.get_member(int(next((u for u, s in regs if s == p["steamid"]), 0)))
                if member:
                    playing.append(f"[{member.display_name}](https://steamcommunity.com/profiles/{p['steamid']}/)")

        if playing:
            embed = discord.Embed(title=f"🎮 {full_name}", description="\n".join(playing), color=0x1c73ff)
            await interaction.followup.send(embed=embed)
        else:
            await interaction.followup.send(embed=discord.Embed(title=f"🎮 {full_name}", description="😴 Nobody playing", color=0x808080))

    # /nowplaying
    @app_commands.command(name="nowplaying", description="Show what all registered users are playing now")
    async def nowplaying(self, interaction: discord.Interaction):
        regs = await get_registered_users(interaction.guild.id)
        if not regs:
            return await interaction.response.send_message(embed=discord.Embed(title="🎮 Now Playing", description="No registered users.", color=0x808080))

        steam_ids = [s for (_u, s) in regs]
        summaries = await steam_get_player_summaries(steam_ids)

        lines = []
        for u, s in regs:
            member = interaction.guild.get_member(u)
            player = next((p for p in summaries if p["steamid"] == s), None)
            if player and player.get("gameextrainfo"):
                lines.append(f"[{member.display_name}](https://steamcommunity.com/profiles/{s}/) → {player['gameextrainfo']}")

        if lines:
            embed = discord.Embed(title="🎮 Now Playing", description="\n".join(lines), color=0x1c73ff)
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message(embed=discord.Embed(title="🎮 Now Playing", description="😴 Nobody is playing right now.", color=0x808080))

    # /top
    @app_commands.command(name="top", description="Show top players by hours in game")
    async def top(self, interaction: discord.Interaction, game: str):
        self.applist = await load_applist()
        full_name, appid = await resolve_game(game, self.applist)
        if not appid:
            return await interaction.response.send_message("Game not found.", ephemeral=True)

        regs = await get_registered_users(interaction.guild.id)
        results = []
        for u, s in regs:
            games = await steam_get_owned_games(s)
            g = next((g for g in games if g["appid"] == appid), None)
            if g:
                member = interaction.guild.get_member(u)
                if member:
                    results.append((member.display_name, s, g["playtime_forever"] // 60))

        if results:
            results.sort(key=lambda x: x[2], reverse=True)
            lines = [f"{i+1}. [{n}](https://steamcommunity.com/profiles/{sid}/) — {h}h" for i, (n, sid, h) in enumerate(results)]
            embed = discord.Embed(title=f"🏆 Top in {full_name}", description="\n".join(lines), color=0xFFD700)
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message(embed=discord.Embed(title=f"🏆 Top in {full_name}", description="Nobody has hours in this game.", color=0x808080))

    # /compare
    @app_commands.command(name="compare", description="Compare playtime in a game between 2 users")
    async def compare(self, interaction: discord.Interaction, user1: discord.Member, user2: discord.Member, game: str):
        self.applist = await load_applist()
        full_name, appid = await resolve_game(game, self.applist)
        if not appid:
            return await interaction.response.send_message("Game not found.", ephemeral=True)

        regs = await get_registered_users(interaction.guild.id)
        id_map = dict(regs)

        if user1.id not in id_map or user2.id not in id_map:
            return await interaction.response.send_message(embed=discord.Embed(title="❌ Error", description="One or both users are not registered.", color=0xFF0000))

        async def get_hours(uid: int) -> int:
            sid = id_map.get(uid)
            games = await steam_get_owned_games(sid)
            g = next((g for g in games if g["appid"] == appid), None)
            return g["playtime_forever"] // 60 if g else 0

        h1, h2 = await get_hours(user1.id), await get_hours(user2.id)
        embed = discord.Embed(title=f"⏱️ Compare in {full_name}", color=0x1c73ff)
        embed.add_field(name=user1.display_name, value=f"[{h1}h](https://steamcommunity.com/profiles/{id_map[user1.id]}/)")
        embed.add_field(name=user2.display_name, value=f"[{h2}h](https://steamcommunity.com/profiles/{id_map[user2.id]}/)")
        await interaction.response.send_message(embed=embed)

    # /gamestats
    @app_commands.command(name="gamestats", description="Detailed stats of a Steam user")
    async def gamestats(self, interaction: discord.Interaction, steamid: str):
        if not is_valid_steamid64(steamid):
            return await interaction.response.send_message("Invalid SteamID.", ephemeral=True)

        # app_xyz
        await interaction.response.defer()

        summaries = await steam_get_player_summaries([steamid])
        if not summaries:
            return await interaction.followup.send("Not found.")

        # --- ban zapros ---
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://api.steampowered.com/ISteamUser/GetPlayerBans/v1/",
                params={"key": STEAM_API_KEY, "steamids": steamid}
            ) as resp:
                bans_data = await resp.json()
        bans = bans_data.get("players", [{}])[0]

        # --- get owned games ---
        most_played = None
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/",
                params = {
                    "key": STEAM_API_KEY,
                    "steamid": steamid,
                    "include_appinfo": "true",
                    "include_played_free_games": "true"
                    }

            ) as resp:
                games_data = await resp.json()
        games = games_data.get("response", {}).get("games", [])
        if games:
            most_played = max(games, key=lambda g: g.get("playtime_forever", 0))

        p = summaries[0]

        # ID
        steamid64 = p["steamid"]
        steamid32 = str(int(steamid64) - 76561197960265728)
        steamid3 = f"U:1:{steamid32}"
        steamid_legacy = f"STEAM_0:{int(steamid32) % 2}:{int(steamid32) // 2}"

        # status
        status_map = {
            0: "Offline",
            1: "Online",
            2: "Busy",
            3: "Away",
            4: "Snooze",
            5: "Looking to Trade",
            6: "Looking to Play"
        }
        state = status_map.get(p.get("personastate", 0), "Unknown")
        status_emoji = ":green_circle:" if p.get("personastate", 0) == 1 else ":red_circle:"

        # date
        created = (
            datetime.utcfromtimestamp(p.get("timecreated"))
            .strftime("%d.%m.%Y %H:%M:%S")
            if p.get("timecreated") else "Unknown"
        )
        lastlogoff = (
            datetime.utcfromtimestamp(p.get("lastlogoff"))
            .strftime("%d.%m.%Y %H:%M:%S")
            if p.get("lastlogoff") else "Unknown"
        )

        # strana
        loc = f":flag_{p.get('loccountrycode','').lower()}:" if p.get("loccountrycode") else "Unknown"

        # visibility
        visibility = ":busts_in_silhouette: Public" if p.get("communityvisibilitystate", 0) == 3 else "Private"

        # --- bans ---
        vac = f":x: {bans['NumberOfVACBans']} VAC ban(s)" if bans.get("NumberOfVACBans", 0) > 0 else ":white_check_mark: None"
        comm = ":x: Banned" if bans.get("CommunityBanned") else ":white_check_mark: None"
        gamebans = f"{bans.get('NumberOfGameBans', 0)}"

        embed = discord.Embed(
            title=p.get("personaname", "Unknown"),
            url=p.get("profileurl"),
            color=0x1c73ff
        )
        embed.set_thumbnail(url=p.get("avatarfull"))

        # status
        embed.add_field(name="Status", value=f"{status_emoji} {state}", inline=True)

        # id and info
        embed.add_field(name="Main Stats", value=(
            f"SteamID: {steamid_legacy}\n"
            f"SteamID 64: {steamid64}\n"
            f"SteamID 3: {steamid3}\n"
            f"SteamID 32: {steamid32}\n"
            f"Country: {loc}\n"
            f"Profile link: [Click]({p.get('profileurl')})\n"
            f"Profile visibility: {visibility}\n"
            f"Created at: {created}\n"
            f"Last logoff: {lastlogoff}"
        ), inline=False)

        # bans
        embed.add_field(name="Bans", value=(
            f"VAC: {vac}\n"
            f"Community: {comm}\n"
            f"Game bans: {gamebans}"
        ), inline=False)

        # game
        if p.get("gameextrainfo"):
            embed.add_field(name="Now Playing", value=p["gameextrainfo"], inline=False)

        # most played
        if most_played:
            hours = most_played["playtime_forever"] // 60
            embed.add_field(
                name="Most Played Game",
                value=f"{most_played['name']} ({hours}h)",
                inline=False
            )

        # lox
        await interaction.followup.send(embed=embed)




# =============================
# sync
# =============================
@bot.event
async def on_ready():
    await bot.add_cog(SteamLobby(bot))
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} commands")
    except Exception as e:
        print("Sync error", e)
    print(f"Logged in as {bot.user}")

if __name__ == "__main__":
    bot.run(DISCORD_TOKEN)
